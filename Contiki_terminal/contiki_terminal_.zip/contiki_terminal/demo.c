// demo.c
#include "contiki.h"
#include "sys/etimer.h" // etimer Event Timer
#include "mytemp.h"
#include <stdio.h>
#include <time.h>

PROCESS(sensor_process, "Sensor process");
AUTOSTART_PROCESSES(&sensor_process);

static struct etimer timer;

int machine_id;
int cycle = 1;

PROCESS_THREAD(sensor_process, ev, data)
{
  PROCESS_BEGIN();
  printf("Native Sensor\n");
  printf("Machine_ID      Timestamp            Date     cycle  sett1  sett2  sett3  s1    s2    s3    s4    s5   s6   s7   s8   s9   s10   s11   s12   s13   s14   s15\n");
  
  while (1) {
    etimer_set(&timer, CLOCK_SECOND * 1);
    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&timer));

    time_t now = time(NULL);
    struct tm *tm_info = localtime(&now);
    char timestamp[20];
    strftime(timestamp, sizeof(timestamp), "%H:%M:%S", tm_info);
    char date[20];
    strftime(date, sizeof(date), "%Y-%m-%d", tm_info);

    if (machine_id != 11 && cycle%5 != 0){
      printf("  %d        \t%s        %s   %d", machine_id, timestamp, date,cycle);

      struct Sensor st1 = read_st1();
      printf("    %.2f", (double)st1.value);
      
      struct Sensor st2 = read_st2();
      printf("    %.2f", (double)st2.value);
      
      struct Sensor st3 = read_st3();
      printf("    %.2f", (double)st3.value);

      struct Sensor s1 = read_s1();
      printf("    %.2f", (double)s1.value);

      struct Sensor s2 = read_s2();
      printf("    %.2f", (double)s2.value);

      struct Sensor s3 = read_s3();
      printf("    %.2f", (double)s3.value);

      struct Sensor s4 = read_s4();
      printf("    %.2f", (double)s4.value);

      struct Sensor s5 = read_s5();
      printf("    %.2f", (double)s5.value);
      
      struct Sensor s6 = read_s6();
	printf("    %.2f", (double)s6.value);

	struct Sensor s7 = read_s7();
	printf("    %.2f", (double)s7.value);


	struct Sensor s8 = read_s8();
	printf("    %.2f", (double)s8.value);

	struct Sensor s9 = read_s9();
	printf("    %.2f", (double)s9.value);
	
	struct Sensor s10 = read_s10();
printf("    %.2f", (double)s10.value);

struct Sensor s11 = read_s11();
printf("    %.2f", (double)s11.value);

struct Sensor s12 = read_s12();
printf("    %.2f", (double)s12.value);

struct Sensor s13 = read_s13();
printf("    %.2f", (double)s13.value);

struct Sensor s14 = read_s14();
printf("    %.2f", (double)s14.value);

struct Sensor s15 = read_s15();
printf("    %.2f\n", (double)s15.value);

    }

    if (machine_id == 10) {
      machine_id = 0;
      cycle = cycle +1;
    }
    
    
    


    machine_id = machine_id + 1;
    
  }
  PROCESS_END();
}

