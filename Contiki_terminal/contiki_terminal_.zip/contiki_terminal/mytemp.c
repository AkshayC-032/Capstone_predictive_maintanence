#include "mytemp.h"
#include <string.h>
#include <stdlib.h>

float random_value(float min ,float max)
{
 float scale = rand() / (float) RAND_MAX;
 return min + scale * (max - min);
}


struct Sensor read_s1()
{
 struct Sensor s1;
 strncpy(s1.name, "s1", 15);
 s1.value = random_value(25,32);
 return s1;
}
struct Sensor read_s2()
{
 struct Sensor s2;
 strncpy(s2.name, "s2", 15);
 s2.value = random_value(40, 80);
 return s2;
}

struct Sensor read_s3()
{
 struct Sensor s3;
 strncpy(s3.name, "s3", 15);
 s3.value = random_value(30, 78);
 return s3;
}

struct Sensor read_s4()
{
 struct Sensor s4;
 strncpy(s4.name,"s4",15);
 s4.value = random_value(1000,3000);
 return s4;
}

struct Sensor read_s5()
{
 struct Sensor s5;
 strncpy(s5.name,"s5",15);
 s5.value = random_value(0,28);
 return s5;
}

struct Sensor read_s6()
{
 struct Sensor s6;
 strncpy(s6.name,"s6",15);
 s6.value = random_value(0,28);
 return s6;
}

struct Sensor read_s7()
{
 struct Sensor s7;
 strncpy(s7.name,"s7",15);
 s7.value = random_value(0,28);
 return s7;
}

struct Sensor read_s8()
{
 struct Sensor s8;
 strncpy(s8.name,"s8",15);
 s8.value = random_value(0,28);
 return s8;
}

struct Sensor read_s9()
{
 struct Sensor s9;
 strncpy(s9.name,"s9",15);
 s9.value = random_value(0,28);
 return s9;
}

struct Sensor read_s10()
{
 struct Sensor s10;
 strncpy(s10.name,"s10",15);
 s10.value = random_value(0,28);
 return s10;
}

struct Sensor read_s11()
{
 struct Sensor s11;
 strncpy(s11.name,"s11",15);
 s11.value = random_value(0,28);
 return s11;
}

struct Sensor read_s12()
{
 struct Sensor s12;
 strncpy(s12.name,"s12",15);
 s12.value = random_value(0,28);
 return s12;
}

struct Sensor read_s13()
{
 struct Sensor s13;
 strncpy(s13.name,"s13",15);
 s13.value = random_value(0,28);
 return s13;
}

struct Sensor read_s14()
{
 struct Sensor s14;
 strncpy(s14.name,"s14",15);
 s14.value = random_value(0,28);
 return s14;
}

struct Sensor read_s15()
{
 struct Sensor s15;
 strncpy(s15.name,"s15",15);
 s15.value = random_value(0,28);
 return s15;
}

struct Sensor read_st1()
{
   struct Sensor st1;
 strncpy(st1.name,"st1",15);
 st1.value = random_value(0,28);
 return st1;

}

struct Sensor read_st2()
{
   struct Sensor st2;
 strncpy(st2.name,"st2",15);
 st2.value = random_value(0,28);
 return st2;

}

struct Sensor read_st3()
{
   struct Sensor st3;
 strncpy(st3.name,"st3",15);
 st3.value = random_value(0,28);
 return st3;

}


