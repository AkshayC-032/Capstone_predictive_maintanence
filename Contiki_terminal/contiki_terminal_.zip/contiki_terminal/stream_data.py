import time
import MySQLdb

conn = MySQLdb.connect('localhost', 'contiki', 'anurag', 'contiki')
cur = conn.cursor()

# Check if the table exists
cur.execute("SHOW TABLES LIKE 'data'")
table_exists = cur.fetchone()

# Create the table if it doesn't exist
if not table_exists:
    cur.execute('''CREATE TABLE data (
                    Machine_ID VARCHAR(255),
                    Timestamp TIME,
                    Date DATE,
                    Temp FLOAT,
                    Humi FLOAT,
                    Pres FLOAT,
                    Rot FLOAT,
                    Vib FLOAT)''')
    conn.commit()

# Start reading after 10 seconds
time.sleep(1)

# Open the file and skip the first 10 lines
with open('data.txt', 'r') as f:
    for i in range(8):
        next(f)
    for line in f:
        # Split the data into columns
        columns = line.split()
        Machine_ID, Timestamp, Date, Temp, Humi, Pres, Rot, Vib = columns

        # Insert the data into the table
        cur.execute('''INSERT INTO data (Machine_ID, Timestamp, Date, Temp, Humi, Pres, Rot, Vib)
                       VALUES (%s, %s, %s, %s, %s, %s, %s, %s)''',
                    (Machine_ID, Timestamp, Date, Temp, Humi, Pres, Rot, Vib))
        conn.commit()

        time.sleep(3)

conn.close()

