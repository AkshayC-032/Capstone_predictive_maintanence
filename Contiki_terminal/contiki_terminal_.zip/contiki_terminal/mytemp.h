// mytemp.h

#ifndef MYTEMP_H
#define MYTEMP_H

struct Sensor{
	char name[15];
	float value;
};

struct Sensor read_s1();
struct Sensor read_s2();
struct Sensor read_s3();
struct Sensor read_s4();
struct Sensor read_s5();
struct Sensor read_s6();
struct Sensor read_s7();
struct Sensor read_s8();
struct Sensor read_s9();
struct Sensor read_s10();
struct Sensor read_s11();
struct Sensor read_s12();
struct Sensor read_s13();
struct Sensor read_s14();
struct Sensor read_s15();
struct Sensor read_st1();
struct Sensor read_st2();
struct Sensor read_st3();

#endif


